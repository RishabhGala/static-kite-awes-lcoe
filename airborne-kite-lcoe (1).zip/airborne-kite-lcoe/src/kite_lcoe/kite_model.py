"""Static-kite and tether force model.

Given altitude-dependent wind speed and air density, finds the kite altitude
and tether elevation angle at which the kite is stable, by (1) solving for the
tether angle at which the net force on the kite points along the tether, and
(2) discretising the tether into segments to find the altitude at which the
tether reaches the ground.
"""

import numpy as np
from scipy.optimize import minimize_scalar

from . import config as cfg

_PI = 3.14159  # TODO: switch to np.pi (kept as-is to reproduce the original results)


# --- Aerodynamic models: replace these with your own kite's data -------------
def get_cl(theta):
    """Kite lift coefficient as a function of tether angle (radians)."""
    return np.cos(theta)


def get_cd(theta):
    """Kite drag coefficient as a function of tether angle (radians)."""
    return np.cos(theta)


def force_from_turbine(speed, density, theta):
    """Lift-like and drag-like force from the turbine (lift, drag)."""
    net_force = 0.5 * 1.0 * density * (speed * np.cos(theta)) ** 2
    return net_force * np.sin(theta), net_force * np.cos(theta)


def sum_vectors_radians(angles, magnitudes):
    """Sum 2D vectors given as (angle in radians, magnitude); return (magnitude, angle)."""
    angles = np.array(angles)
    magnitudes = np.array(magnitudes)
    sum_x = np.sum(magnitudes * np.cos(angles))
    sum_y = np.sum(magnitudes * np.sin(angles))
    return np.hypot(sum_x, sum_y), np.arctan2(sum_y, sum_x)


def find_alt_and_theta(wind_fn, density_fn, tether_length, segments=10):
    """Find the stable kite altitude and tether angle for a given tether length.

    Returns ``(altitude, theta, max_tension, residual)``. ``residual`` is the
    height of the tether base above ground for the best altitude; a value
    above ~1 (or the 1000 sentinel) means no valid flight configuration exists.
    """
    g = cfg.GRAVITY
    kite_area = cfg.KITE_AREA
    kite_mass = cfg.KITE_MASS
    diameter = cfg.TETHER_DIAMETER

    def get_theta(alt):
        multiplier = density_fn(alt) * wind_fn(alt) * wind_fn(alt) * kite_area / 2

        def theta_cost(theta):
            turb_lift, turb_drag = force_from_turbine(wind_fn(alt), density_fn(alt), theta)
            force_angle = np.arctan(
                (multiplier * get_cl(theta) - g * kite_mass + turb_lift)
                / (multiplier * get_cd(theta) + turb_drag)
            )
            return (force_angle - theta) ** 2

        result = minimize_scalar(
            theta_cost,
            bounds=(np.radians(1), np.radians(90)),
            method="bounded",
            options={"xatol": 1e-1},
        )
        return result.x

    def segment_forces(alt, theta, tension, seg_len):
        """Forces on one tether segment: tension from above, weight, wind drag."""
        angles = [theta, _PI * 1.5, theta - _PI / 2]
        mags = [
            tension,
            cfg.TETHER_LINEAR_DENSITY * seg_len * g,
            0.5 * density_fn(alt) * (np.sin(theta) * wind_fn(alt)) ** 2
            * cfg.TETHER_DRAG_COEFF * seg_len * diameter,
        ]
        return angles, mags

    def alt_cost(alt):
        theta = get_theta(alt)
        multiplier = density_fn(alt) * wind_fn(alt) * wind_fn(alt) * kite_area / 2
        tension = np.sqrt(
            (multiplier * get_cl(theta) - g * kite_mass) ** 2
            + (multiplier * get_cd(theta)) ** 2
        )
        seg_len = tether_length / segments
        for _ in range(segments):
            angles, mags = segment_forces(alt, theta, tension, seg_len)
            alt -= seg_len * np.sin(theta)
            if alt < 0:
                return 1000
            tension, theta = sum_vectors_radians(angles, mags)
            if theta > _PI / 2 or theta < 0.0:
                return 1000
        return alt

    final = minimize_scalar(
        alt_cost, bounds=(2, tether_length - 2), method="bounded", options={"xatol": 1e-1}
    )

    # Re-run the tether march at the optimum to record the maximum tension
    alt = final.x
    theta = get_theta(alt)
    multiplier = density_fn(alt) * wind_fn(alt) * wind_fn(alt) * kite_area / 2
    tension = np.sqrt(
        (multiplier * get_cl(theta) - g * kite_mass) ** 2 + (multiplier * get_cd(theta)) ** 2
    )
    max_tension = tension
    seg_len = tether_length / segments
    for _ in range(segments):
        angles, mags = segment_forces(alt, theta, tension, seg_len)
        alt -= seg_len * np.sin(theta)
        tension, theta = sum_vectors_radians(angles, mags)
        max_tension = max(max_tension, tension)

    return final.x, get_theta(final.x), max_tension, final.fun
