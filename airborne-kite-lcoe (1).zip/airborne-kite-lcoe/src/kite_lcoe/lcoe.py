"""Levelized cost of energy (LCOE) and its optimisation."""

from scipy.optimize import minimize

from . import config as cfg
from .cost import get_cost
from .energy import get_average_energy


def get_lcoe(climate, land, lat, lon, times):
    """Minimum LCOE (cents/kWh) at a location, with average power taken over ``times``
    (a sequence of ``numpy.datetime64``).

    The optimised parameter is the maximum tether length. Add further design
    parameters by extending ``params`` in ``objective``.
    """
    on_land = land.is_on_land(lat, lon)

    def objective(params):
        max_tether_length = params[0]
        avg_energy = get_average_energy(climate, lat, lon, max_tether_length, times)
        if avg_energy == 0:
            return 1e6  # no usable energy: large penalty
        cost = get_cost(max_tether_length, on_land)
        return cost / cfg.TOTAL_OPERATIONAL_HOURS / avg_energy * 1000 * 100

    result = minimize(
        objective, [cfg.INITIAL_MAX_TETHER_LENGTH], method="COBYLA", options={"tol": 1}
    )
    return result.fun
