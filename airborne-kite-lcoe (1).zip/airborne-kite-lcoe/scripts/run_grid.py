"""Compute LCOE over a latitude/longitude grid and write the results to a text file.

Required input files (supply the paths on the command line):
  * ERA5 pressure-level GRIB file: temperature and u/v wind components at 1000-650 hPa
  * ERA5 single-level GRIB file:   2 m temperature and surface pressure
  * Natural Earth land-polygon shapefile (zipped or unzipped), used to decide land vs. offshore

Also supply the grid to evaluate (latitude/longitude bounds and spacing) and the times to
average power output over. The climate files must cover the chosen region and times.

Output format (two lines per grid point, read by plot_map.py):
    <lat> <lon>
    <lcoe>
"""

import argparse
from pathlib import Path

import numpy as np

from kite_lcoe.climate import ClimateData
from kite_lcoe.land import LandMask
from kite_lcoe.lcoe import get_lcoe


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--pressure-file", required=True,
                   help="path to the ERA5 pressure-level GRIB file (temperature, u/v wind)")
    p.add_argument("--single-file", required=True,
                   help="path to the ERA5 single-level GRIB file (2 m temperature, surface pressure)")
    p.add_argument("--land-shapefile", required=True,
                   help="path to the Natural Earth land-polygon shapefile")
    p.add_argument("--output", required=True,
                   help="path of the text file to write LCOE results to")
    p.add_argument("--lat-min", type=float, required=True, help="southern edge of the grid (degrees)")
    p.add_argument("--lat-max", type=float, required=True, help="northern edge of the grid (degrees)")
    p.add_argument("--lon-min", type=float, required=True, help="western edge of the grid (degrees)")
    p.add_argument("--lon-max", type=float, required=True, help="eastern edge of the grid (degrees)")
    p.add_argument("--step", type=float, required=True, help="grid spacing in degrees")
    p.add_argument("--times", nargs="+", required=True, metavar="YYYY-MM-DDTHH:MM",
                   help="one or more UTC timestamps to average power output over")
    args = p.parse_args()

    times = [np.datetime64(t) for t in args.times]
    climate = ClimateData(args.pressure_file, args.single_file)
    land = LandMask(args.land_shapefile)

    n_lat = round((args.lat_max - args.lat_min) / args.step) + 1
    n_lon = round((args.lon_max - args.lon_min) / args.step) + 1

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w") as f:
        for i in range(n_lon):
            for j in range(n_lat):
                lat = args.lat_min + args.step * j
                lon = args.lon_min + args.step * i
                lcoe = float(get_lcoe(climate, land, lat, lon, times))
                print(lat, lon, lcoe, flush=True)
                f.write(f"{lat} {lon}\n{lcoe}\n")
                f.flush()  # keep partial results if the run is interrupted


if __name__ == "__main__":
    main()
