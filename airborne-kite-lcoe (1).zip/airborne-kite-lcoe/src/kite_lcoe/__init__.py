"""Static-kite airborne wind energy (AWES) LCOE model."""

__version__ = "0.1.0"
