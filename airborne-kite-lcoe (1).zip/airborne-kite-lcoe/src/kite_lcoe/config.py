"""Default model parameters.

All physical quantities are in SI units and all costs are in USD. Many values
come from patent US8602363B2 (https://patents.google.com/patent/US8602363B2/en)
or are semi-arbitrary placeholders used to test the model. Edit them here (or
override them at runtime, e.g. ``config.KITE_AREA = 100``) to model a
different system.
"""

# --- Kite and tether ---------------------------------------------------------
KITE_AREA = 128.0            # m^2
KITE_MASS = 217.6            # kg
TETHER_DIAMETER = 5e-3       # m
TETHER_LINEAR_DENSITY = 0.04 # kg/m
TETHER_DRAG_COEFF = 1.1      # cylinder drag coefficient
TETHER_SEGMENTS = 10         # tether discretisation (more = more accurate)
MAX_ALTITUDE = 1000.0        # m, energy is set to 0 above this
GRAVITY = 9.807              # m/s^2 (used in the kite/tether force balance)
EFFICIENCY = 0.2             # overall conversion efficiency

# --- Climate-data fitting ----------------------------------------------------
WIND_FIT_DEGREE = 6          # polynomial degree, wind speed vs altitude
DENSITY_FIT_DEGREE = 3       # polynomial degree, air density vs altitude

# --- Costs (USD) -------------------------------------------------------------
KITE_COST_PER_KG = 117.1875        # $15,000 for a 128 m^2 kite, scaled by mass
CONTROL_UNIT_COST = 10_000
TETHER_COST_PER_METER_REF = 28.5714285714  # at TETHER_DIAMETER_REF
TETHER_DIAMETER_REF = 5e-3                 # m; tether cost scales with diameter^2
WINCH_COST = 100_000
LAUNCH_AND_RECOVERY_SYSTEM_COST = 50_000
FLYWHEEL_COST = 200_000
GENERATOR_COST = 100_000
BASE_STRUCTURE_COST = 200_000
OFFSHORE_BASE_MULTIPLIER = 5       # base structure costs 5x if the site is offshore
MISCELLANEOUS_PARTS_COST = 200_000 # clutches, gears, motor/generator, etc.
YAW_MOTOR_COST = 20_000
WEATHER_INSTRUMENTS_COST = 5_000
FLIGHT_SOFTWARE_COST = 50_000      # development, testing, maintenance (per unit)
OPERATIONAL_COST = 25_000          # monitoring, repairs, upgrades, etc.
TOTAL_OPERATIONAL_HOURS = 40_000

# --- Optimiser ---------------------------------------------------------------
INITIAL_MAX_TETHER_LENGTH = 100.0  # m, starting guess for the optimised parameter
