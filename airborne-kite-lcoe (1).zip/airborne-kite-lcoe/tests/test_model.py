"""Smoke tests that need no external data."""

import numpy as np
import pytest

from kite_lcoe import config as cfg
from kite_lcoe.cost import get_cost
from kite_lcoe.kite_model import find_alt_and_theta, sum_vectors_radians


def test_sum_vectors():
    mag, ang = sum_vectors_radians([0.0, np.pi / 2], [3.0, 4.0])
    assert mag == pytest.approx(5.0)
    assert ang == pytest.approx(np.arctan2(4.0, 3.0))


def test_offshore_costs_more_than_onshore():
    diff = get_cost(1000, on_land=False) - get_cost(1000, on_land=True)
    assert diff == pytest.approx((cfg.OFFSHORE_BASE_MULTIPLIER - 1) * cfg.BASE_STRUCTURE_COST)


def test_cost_grows_with_tether_length():
    assert get_cost(2000, True) > get_cost(1000, True)


def test_find_alt_and_theta_returns_valid_angle():
    wind = lambda alt: 8.0 + 0.004 * alt          # m/s, synthetic profile
    density = lambda alt: 1.225 - 1.1e-4 * alt    # kg/m^3, synthetic profile
    alt, theta, max_tension, residual = find_alt_and_theta(wind, density, 1000.0)
    assert np.radians(1) - 1e-9 <= theta <= np.pi / 2 + 1e-9
    assert np.isfinite(alt) and np.isfinite(max_tension) and np.isfinite(residual)
