"""Lifetime cost model (USD)."""

from . import config as cfg


def get_cost(max_tether_length, on_land):
    """Total system cost for a given maximum tether length and site type.

    Tether cost per metre scales with the square of the tether diameter, and
    the base structure costs ``OFFSHORE_BASE_MULTIPLIER`` times more offshore.
    """
    tether_cost_per_meter = cfg.TETHER_COST_PER_METER_REF * (
        cfg.TETHER_DIAMETER / cfg.TETHER_DIAMETER_REF
    ) ** 2
    base_structure_cost = cfg.BASE_STRUCTURE_COST
    if not on_land:
        base_structure_cost *= cfg.OFFSHORE_BASE_MULTIPLIER

    return (
        cfg.KITE_COST_PER_KG * cfg.KITE_MASS
        + cfg.CONTROL_UNIT_COST
        + tether_cost_per_meter * max_tether_length
        + cfg.WINCH_COST
        + cfg.LAUNCH_AND_RECOVERY_SYSTEM_COST
        + cfg.FLYWHEEL_COST
        + cfg.GENERATOR_COST
        + base_structure_cost
        + cfg.MISCELLANEOUS_PARTS_COST
        + cfg.YAW_MOTOR_COST
        + cfg.WEATHER_INSTRUMENTS_COST
        + cfg.FLIGHT_SOFTWARE_COST
        + cfg.OPERATIONAL_COST
    )
