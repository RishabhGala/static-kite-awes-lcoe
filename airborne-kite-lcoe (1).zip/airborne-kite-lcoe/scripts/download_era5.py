"""Download the ERA5 data needed by the model from the Copernicus Climate Data Store.

Requires a free CDS account and API key (see https://cds.climate.copernicus.eu/how-to-api)
and the ``cdsapi`` package (``pip install -e ".[download]"``).

Two output files are written (you choose their paths):
  * pressure levels: temperature, u/v wind at 1000-650 hPa
  * single levels:   2 m temperature, surface pressure
You choose the region and the dates/times to download; they must cover the locations and
times you later pass to run_grid.py.
"""

import argparse
from pathlib import Path

import cdsapi

PRESSURE_LEVELS = [str(1000 - 25 * i) for i in range(15)]  # 1000 ... 650 hPa


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--pressure-out", required=True,
                   help="path of the GRIB file to write the pressure-level data to")
    p.add_argument("--single-out", required=True,
                   help="path of the GRIB file to write the single-level data to")
    p.add_argument("--year", nargs="+", required=True, help="year(s), e.g. 2024")
    p.add_argument("--month", nargs="+", required=True, help="month(s) as two digits, e.g. 06")
    p.add_argument("--day", nargs="+", required=True, help="day(s) as two digits, e.g. 01 02")
    p.add_argument("--time", nargs="+", required=True, help="UTC times as HH:MM, e.g. 12:00 13:00")
    p.add_argument("--area", nargs=4, type=float, required=True,
                   metavar=("NORTH", "WEST", "SOUTH", "EAST"),
                   help="bounding box in degrees; pad it slightly beyond your grid edges")
    args = p.parse_args()

    for path in (args.pressure_out, args.single_out):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    client = cdsapi.Client()

    common = {
        "product_type": ["reanalysis"],
        "year": args.year,
        "month": args.month,
        "day": args.day,
        "time": args.time,
        "data_format": "grib",
        "download_format": "unarchived",
        "area": args.area,
    }

    client.retrieve(
        "reanalysis-era5-pressure-levels",
        {**common,
         "variable": ["temperature", "u_component_of_wind", "v_component_of_wind"],
         "pressure_level": PRESSURE_LEVELS},
        args.pressure_out,
    )
    client.retrieve(
        "reanalysis-era5-single-levels",
        {**common, "variable": ["2m_temperature", "surface_pressure"]},
        args.single_out,
    )


if __name__ == "__main__":
    main()
