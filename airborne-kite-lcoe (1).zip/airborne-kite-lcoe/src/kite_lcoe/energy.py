"""Power output of the kite at a location and time."""

import numpy as np
from scipy.optimize import minimize_scalar

from . import config as cfg
from .kite_model import find_alt_and_theta


def get_energy(climate, lat, lon, tether_length, time):
    """Power output (W) for one location, tether length and time.

    Returns 0 if no valid kite altitude exists or the altitude exceeds
    ``config.MAX_ALTITUDE``. Replace the final expression with your own
    power model if needed.
    """
    wind_fn, density_fn = climate.altitude_profiles(lat, lon, time)
    alt, theta, _max_tension, residual = find_alt_and_theta(
        wind_fn, density_fn, tether_length, segments=cfg.TETHER_SEGMENTS
    )
    if residual > 1:
        return 0
    if alt > cfg.MAX_ALTITUDE:
        return 0
    return (
        cfg.EFFICIENCY * 0.5 * density_fn(alt) * (wind_fn(alt) ** 3)
        * cfg.KITE_AREA * np.cos(theta)
    )


def get_average_energy(climate, lat, lon, max_tether_length, times):
    """Average power over ``times`` (a sequence of ``numpy.datetime64``), using the best
    tether length in [0, max_tether_length] at each time."""
    if len(times) == 0:
        raise ValueError("At least one time must be provided to average power over.")
    total = 0.0
    for t in times:
        def neg_energy(tether_length, t=t):
            return -1 * get_energy(climate, lat, lon, tether_length, t)

        result = minimize_scalar(
            neg_energy,
            bounds=(0, max_tether_length),
            method="bounded",
            options={"xatol": 1e-1},
        )
        total += -1 * result.fun
    return total / len(times)
