"""Land-mask test.

Set the environment variable KITE_LCOE_LAND_SHAPEFILE to the path of a Natural Earth
land-polygon shapefile to run it; otherwise it is skipped.
"""

import os

import pytest

pytest.importorskip("geopandas")
SHAPEFILE = os.environ.get("KITE_LCOE_LAND_SHAPEFILE")
pytestmark = pytest.mark.skipif(
    not SHAPEFILE or not os.path.exists(SHAPEFILE),
    reason="KITE_LCOE_LAND_SHAPEFILE not set to an existing file",
)

from kite_lcoe.land import LandMask  # noqa: E402


def test_land_and_sea():
    land = LandMask(SHAPEFILE)
    assert land.is_on_land(0.0, 20.0)        # inland (central Africa)
    assert not land.is_on_land(0.0, -30.0)   # open ocean (mid-Atlantic)
