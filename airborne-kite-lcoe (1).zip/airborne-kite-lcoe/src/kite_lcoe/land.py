"""Land / sea classification using the Natural Earth land polygons."""

from pathlib import Path

import geopandas as gpd
from shapely.geometry import Point


class LandMask:
    """Answers "is this coordinate on land?" using a Natural Earth shapefile.

    Pass the path to a Natural Earth land-polygon shapefile (from
    https://www.naturalearthdata.com/); zipped shapefiles are read directly.
    """

    def __init__(self, shapefile_path):
        shapefile_path = Path(shapefile_path)
        if not shapefile_path.exists():
            raise FileNotFoundError(
                f"Land shapefile not found: {shapefile_path}. "
                "See the README for the input data required."
            )
        self.land = gpd.read_file(shapefile_path)

    def is_on_land(self, lat, lon):
        point = Point(lon, lat)  # shapely/GeoPandas use (x=lon, y=lat)
        return bool(self.land.contains(point).any())
