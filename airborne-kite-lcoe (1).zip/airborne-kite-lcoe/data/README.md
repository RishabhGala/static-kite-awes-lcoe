# Data

Input data is not committed to the repository; this folder is a suggested place to keep it
(its contents are git-ignored). Three inputs are needed:

1. **ERA5 pressure-level data** (GRIB) from the Copernicus Climate Data Store: temperature and the
   u- and v-components of wind, at pressure levels 1000-650 hPa in 25 hPa steps.
2. **ERA5 single-level data** (GRIB) from the Copernicus Climate Data Store: 2 m temperature and
   surface pressure, for the same region and times.
3. **Land polygons** from Natural Earth (https://www.naturalearthdata.com/): the 1:10m physical
   "Land" shapefile, used to decide whether a location is on land or offshore.

`scripts/download_era5.py` can fetch the two ERA5 files (it needs a free CDS account and API key).
You pass the file paths to the scripts on the command line.
