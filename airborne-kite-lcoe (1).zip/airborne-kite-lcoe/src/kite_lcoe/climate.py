"""ERA5 climate data -> altitude-dependent wind speed and air density.

Pressure-level data (temperature, u/v wind) and single-level data (2 m
temperature, surface pressure) from the Copernicus Climate Data Store are
combined using the hypsometric equation to estimate the altitude of each
pressure level. Polynomials are then fitted for wind speed and air density as
functions of altitude.
"""

import numpy as np
import xarray as xr

from . import config as cfg

# Pressure levels used (hPa): 1000, 975, ..., 650
PRESSURE_LEVELS_HPA = [1000 - 25 * i for i in range(15)]

R_DRY_AIR = 287.052874        # J/(kg K), specific gas constant for dry air
G0 = 9.80665                  # m/s^2, standard gravity (hypsometric equation)
MOLAR_MASS_AIR = 28.964e-3    # kg/mol (assumed constant, see README)
R_GAS = 8.314                 # J/(mol K)


class ClimateData:
    """Holds the two ERA5 GRIB datasets and builds profiles at a location/time."""

    def __init__(self, pressure_level_file, single_level_file):
        self.pl = xr.open_dataset(str(pressure_level_file), engine="cfgrib")
        self.gl = xr.open_dataset(str(single_level_file), engine="cfgrib")

    def altitude_profiles(self, lat, lon, time, debug=False):
        """Return ``(wind_speed_fn, density_fn)``, each a function of altitude (m)."""
        ground = self.gl.sel(latitude=lat, longitude=lon, time=time, method="nearest")
        ground_temp = float(ground["t2m"].values)
        ground_press = float(ground["sp"].values)  # Pa

        alts, speeds, densities = [], [], []
        for p_hpa in PRESSURE_LEVELS_HPA:
            point = self.pl.sel(
                isobaricInhPa=p_hpa, latitude=lat, longitude=lon,
                time=time, method="nearest",
            )
            temp = float(point["t"].values)
            mean_temp = (ground_temp + temp) / 2
            # Hypsometric equation; mean virtual temperature approximated by the mean temperature
            alts.append(R_DRY_AIR * mean_temp / G0 * np.log(ground_press / p_hpa / 100))
            speeds.append(float(np.hypot(point["u"].values, point["v"].values)))
            # Ideal gas law
            densities.append((p_hpa * 100) * MOLAR_MASS_AIR / R_GAS / temp)

        wind_fn = np.poly1d(np.polyfit(alts, speeds, cfg.WIND_FIT_DEGREE))
        density_fn = np.poly1d(np.polyfit(alts, densities, cfg.DENSITY_FIT_DEGREE))

        if debug:
            plot_fit(alts, speeds, wind_fn, "Wind speed (m/s)")
            plot_fit(alts, densities, density_fn, "Air density (kg/m^3)")
        return wind_fn, density_fn


def plot_fit(x, y, model, ylabel):
    """Scatter the observed points and overlay the fitted polynomial."""
    import matplotlib.pyplot as plt

    y = np.asarray(y)
    ss_res = np.sum((y - model(np.asarray(x))) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot
    zvals = np.linspace(min(x), max(x), 100)
    plt.scatter(x, y, label="Observed")
    plt.plot(zvals, model(zvals), color="red", label=f"Fit (R² = {r2:.3f})")
    plt.xlabel("Height (m)")
    plt.ylabel(ylabel)
    plt.legend()
    plt.grid(True)
    plt.show()
