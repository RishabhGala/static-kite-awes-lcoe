"""Plot LCOE results as a coloured-point map.

Required input files (supply the paths on the command line):
  * the LCOE results text file written by run_grid.py
  * the Natural Earth land-polygon shapefile used as the map background
"""

import argparse
from pathlib import Path

import geopandas as gpd
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from shapely.geometry import Point

LCOE_MAX = 30  # values above this are drawn dark grey


def lcoe_to_color(lcoe):
    """Green (0) -> red (30); grey for invalid (<0); dark grey for > 30."""
    if lcoe < 0:
        return (0.5, 0.5, 0.5, 1.0)
    if lcoe <= LCOE_MAX:
        return (lcoe / LCOE_MAX, (LCOE_MAX - lcoe) / LCOE_MAX, 0.0, 1.0)
    return (0.2, 0.2, 0.2, 1.0)


def read_results(path):
    with open(path) as f:
        lines = [ln for ln in f.read().splitlines() if ln.strip()]
    records = []
    for i in range(0, len(lines), 2):
        lat, lon = map(float, lines[i].split())
        records.append((lon, lat, float(lines[i + 1])))
    return pd.DataFrame(records, columns=["lon", "lat", "lcoe"])


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", required=True,
                   help="path to the LCOE results text file produced by run_grid.py")
    p.add_argument("--land-shapefile", required=True,
                   help="path to the Natural Earth land-polygon shapefile")
    p.add_argument("--output", default=None,
                   help="optional path to save the map image to (omit to just display it)")
    args = p.parse_args()

    land = gpd.read_file(args.land_shapefile)
    df = read_results(args.input)
    gdf = gpd.GeoDataFrame(
        df, geometry=[Point(xy) for xy in zip(df["lon"], df["lat"])], crs="EPSG:4326"
    )

    fig, ax = plt.subplots(figsize=(10, 10))
    land.plot(ax=ax, color="lightgrey", edgecolor="white")
    gdf.plot(
        ax=ax,
        facecolor=[lcoe_to_color(v) for v in gdf["lcoe"]],
        edgecolor="black",
        markersize=200,
        linewidth=0.2,
    )

    ax.set_title("Levelized Cost of Energy (LCOE) by Location (¢/kWh)")
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xlim(df["lon"].min() - 0.25, df["lon"].max() + 0.25)
    ax.set_ylim(df["lat"].min() - 0.25, df["lat"].max() + 0.25)

    # Colorbar matching the point colouring over 0..LCOE_MAX
    cmap = mcolors.ListedColormap([lcoe_to_color(v) for v in np.linspace(0, LCOE_MAX, 256)])
    sm = cm.ScalarMappable(cmap=cmap, norm=mcolors.Normalize(vmin=0, vmax=LCOE_MAX))
    sm.set_array([])
    fig.colorbar(sm, ax=ax, orientation="vertical", label="LCOE (¢/kWh)", shrink=0.75)

    ax.legend(
        handles=[mpatches.Patch(color=(0.2, 0.2, 0.2), label=f"LCOE > {LCOE_MAX}")],
        loc="lower left",
        title="Other Values",
    )
    ax.grid(True)
    fig.tight_layout()

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=200)
        print(f"Saved {out}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
